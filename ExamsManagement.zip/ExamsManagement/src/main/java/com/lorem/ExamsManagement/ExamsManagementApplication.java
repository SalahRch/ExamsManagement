package com.lorem.ExamsManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamsManagementApplication.class, args);
	}

}
