package com.lorem.ExamsManagement.model;

public enum Session {
    NORMAL,
    RATTRAPAGE
}
