package com.lorem.ExamsManagement.model;

public enum FilliereType {
    CP,
    GI,
    G2ER,
    G2EE,
    GC,
    GM,
    ID

}
