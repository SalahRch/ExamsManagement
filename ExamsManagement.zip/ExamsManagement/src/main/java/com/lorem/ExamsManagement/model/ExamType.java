package com.lorem.ExamsManagement.model;

public enum ExamType {
    DS,
    EXAM
}
