package com.lorem.ExamsManagement.model;

public enum Semestre {

    PRINTEMPS,
    AUTOMNE
}
