package com.lorem.ExamsManagement.model;

public enum Permissions {
    EDIT,
    VIEW
}
