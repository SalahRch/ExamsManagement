package com.lorem.ExamsManagement.DAO;

import com.lorem.ExamsManagement.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartementDAO extends JpaRepository<Department , Long> {
}
