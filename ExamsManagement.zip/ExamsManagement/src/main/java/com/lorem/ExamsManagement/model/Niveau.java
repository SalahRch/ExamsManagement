package com.lorem.ExamsManagement.model;

public enum Niveau {
    FIRST_YEAR,
    SECOND_YEAR,
    THIRD_YEAR
}
