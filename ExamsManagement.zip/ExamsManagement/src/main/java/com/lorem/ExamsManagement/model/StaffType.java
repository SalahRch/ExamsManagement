package com.lorem.ExamsManagement.model;

public enum StaffType {
    ENSEIGNANT,
    CADRE_ADMINISTRATIF
}
